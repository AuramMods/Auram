#19
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot] 19 ggunz:shot by @s

#15
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot] 12.6 ggunz:shot by @s

tag @e remove gz_headshot

execute positioned ^ ^ ^-0.2 run particle minecraft:block minecraft:light_gray_concrete ~ ~ ~ 0 0 0 0 5

