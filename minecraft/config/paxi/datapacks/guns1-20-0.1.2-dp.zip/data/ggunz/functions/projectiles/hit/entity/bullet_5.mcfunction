

#inf
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] 999 ggunz:pulse by @s

#inf
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] 50 ggunz:pulse by @s



execute as @e[tag=gz_headshot] at @s run playsound minigun:headshot master @a[sort=nearest,distance=1..] ~ ~ ~ 1 1 1
tag @e remove gz_headshot

execute positioned ^ ^ ^-0.2 run particle minecraft:block minecraft:light_gray_concrete ~ ~ ~ 0 0 0 0 5
