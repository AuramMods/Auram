
scoreboard players add @e[type=#ggunz:affected,sort=nearest,limit=1,distance=0] shotgunHit 1


#12
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] .6 ggunz:shot by @s

#6
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] .15 ggunz:shot by @s

tag @e remove gz_headshot

scoreboard players reset @s shotgunHeadshot
