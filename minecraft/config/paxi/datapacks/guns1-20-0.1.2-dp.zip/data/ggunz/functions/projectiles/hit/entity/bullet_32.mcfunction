
scoreboard players add @e[type=#ggunz:affected,sort=nearest,limit=1,distance=0] shotgunHit 1

#12
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] .5 ggunz:shot by @s

#6
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] .125 ggunz:shot by @s


tag @e remove gz_headshot

scoreboard players reset @s shotgunHeadshot

execute if entity @s[type=player] run data merge entity @s {Fire:100s}
execute if entity @s[type=player] as @s at @s run summon small_fireball ~ ~2.1 ~ {Motion:[0.0,-1.0,0.0]}
