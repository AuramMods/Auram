
#12
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] 12 ggunz:shot by @s

#6
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] 6 ggunz:shot by @s

tag @e remove gz_headshot
execute if entity @s run summon armor_stand ~ ~ ~ {Tags:["teslazap"],NoGravity:1b,Marker:1b,Invisible:1b}

execute positioned ^ ^ ^-0.2 run particle minecraft:block minecraft:light_gray_concrete ~ ~ ~ 0 0 0 0 5