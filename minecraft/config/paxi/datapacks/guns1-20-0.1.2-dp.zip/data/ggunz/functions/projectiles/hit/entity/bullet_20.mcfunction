

#10
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=gz_headshot,distance=0] 7.5 ggunz:shot by @s

#5
execute if entity @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] run damage @e[type=#ggunz:affected,sort=nearest,limit=1,tag=!gz_headshot,distance=0] 5 ggunz:shot by @s

tag @e remove gz_headshot
execute positioned ^ ^ ^-0.2 run particle minecraft:block minecraft:light_gray_concrete ~ ~ ~ 0 0 0 0 5
